
from ui.kiosk_ui import launch_kiosk

if __name__ == "__main__":
    launch_kiosk()
