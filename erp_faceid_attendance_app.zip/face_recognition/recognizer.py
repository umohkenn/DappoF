
import face_recognition
import cv2
import os
import pickle

def load_known_faces(db_path="data/known_faces.pkl"):
    if os.path.exists(db_path):
        with open(db_path, "rb") as f:
            return pickle.load(f)
    return []

def recognize_face(frame, known_faces):
    rgb = frame[:, :, ::-1]
    face_locations = face_recognition.face_locations(rgb)
    face_encodings = face_recognition.face_encodings(rgb, face_locations)

    for encoding in face_encodings:
        for known in known_faces:
            result = face_recognition.compare_faces([known['encoding']], encoding)
            if result[0]:
                return known['employee_id']
    return None
