# ERPNext Face ID Attendance App

Refer to documentation for setup.