
import requests
from datetime import datetime

def send_attendance(employee_id, api_key, api_secret, url):
    headers = {
        "Authorization": f"token {api_key}:{api_secret}"
    }
    payload = {
        "employee": employee_id,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "log_type": "IN",
        "device_id": "FaceKiosk01"
    }
    response = requests.post(f"{url}/api/resource/Employee Checkin", json=payload, headers=headers)
    return response.status_code == 200
